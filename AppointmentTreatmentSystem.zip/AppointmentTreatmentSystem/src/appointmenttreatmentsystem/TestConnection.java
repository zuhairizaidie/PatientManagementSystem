/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appointmenttreatmentsystem;

import java.sql.Connection;

public class TestConnection {

    public static void main(String[] args) {

        Connection con = DBconnection.getConnection();

        if(con != null)
        {
            System.out.println("Connection Successful");
        }
        else
        {
            System.out.println("Connection Failed");
        }
    }
}

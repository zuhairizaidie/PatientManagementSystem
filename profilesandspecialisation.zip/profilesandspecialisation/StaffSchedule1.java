/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package profilesandspecialisation;

/**
 *
 * @author irfan
 */
import java.util.List;
public class StaffSchedule1 {

    // --- 1. Private Attributes ---
    private String scheduleID; 
    private String staffID;
    private String staffName;
    private String shiftday;
    private String shiftTime;
    private String department;

    // --- 2. Constructors ---
    public StaffSchedule1() {
        // Empty constructor
    }

    public StaffSchedule1(String scheduleID, String staffID, String staffName, String shiftday, String shiftTime, String department) {
        this.scheduleID = scheduleID;
        this.staffID = staffID;
        this.staffName = staffName;
        this.shiftday = shiftday;
        this.shiftTime = shiftTime;
        this.department = department;
    }

    // --- 3. Getters and Setters ---
    public String getScheduleID() { return scheduleID; }
    public void setScheduleID(String scheduleID) { this.scheduleID = scheduleID; }

    public String getStaffID() { return staffID; }
    public void setStaffID(String staffID) { this.staffID = staffID; }

    public String getStaffName() { return staffName; }
    public void setStaffName(String staffName) { this.staffName = staffName; }

    public String getShiftday() { return shiftday; }
    public void setShiftday(String shiftday) { this.shiftday = shiftday; }

    public String getShiftTime() { return shiftTime; }
    public void setShiftTime(String shiftTime) { this.shiftTime = shiftTime; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    // --- 4. Methods ---
    public void addSchedule() {
        // Database logic goes here
    }
    
    public void modifySchedule() {
        // Database logic goes here
    }
    
    public void deleteSchedule() {
        // Database logic goes here
    }
    
    public List<StaffSchedule1> viewSchedule() {
        return null; // Will eventually return a list from the database
    }
    
    public void clearFields() {
        // Logic to clear GUI fields goes here
    }

    
}

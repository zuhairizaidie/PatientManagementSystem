/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package profilesandspecialisation;

/**
 *
 * @author irfan
 */
import java.util.List;
public class DoctorProfile1 {


    
    // --- 1. Private Attributes ---
    private String doctorId;
    private String doctorName;
    private String specialisation;
    private String contactNumber;

    // --- 2. Constructors ---
    public DoctorProfile1() {
        // Empty constructor
    }

    public DoctorProfile1(String doctorId, String doctorName, String specialisation, String contactNumber) {
        this.doctorId = doctorId;
        this.doctorName = doctorName;
        this.specialisation = specialisation;
        this.contactNumber = contactNumber;
    }

    // --- 3. Getters and Setters ---
    public String getDoctorId() { return doctorId; }
    public void setDoctorId(String doctorId) { this.doctorId = doctorId; }

    public String getDoctorName() { return doctorName; }
    public void setDoctorName(String doctorName) { this.doctorName = doctorName; }

    public String getSpecialisation() { return specialisation; }
    public void setSpecialisation(String specialisation) { this.specialisation = specialisation; }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }

    // --- 4. Methods ---
    public void addDoctor() {
        // Database logic goes here
    }
    
    public void modifyDoctor() {
        // Database logic goes here
    }
    
    public void deleteDoctor() {
        // Database logic goes here
    }
    
    public List<DoctorProfile1> viewDoctor() {
        return null; // Will eventually return a list from the database
    }
    
    public List<DoctorProfile1> searchDoctor() {
        return null; // Will eventually return a list from the database
    }
    
    public void clearFields() {
        // Logic to clear GUI fields goes here
    }

    
}

package profilesandspecialisation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    
    private static final String URL = "jdbc:mysql://localhost:3306/hospital_management";
    private static final String USER = "root"; 
    private static final String PASSWORD = ""; 

    public static Connection getConnection() {
        Connection conn = null;
        try {
            // 1. Explicitly load the MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // 2. Establish the connection
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connection to hospital_management successful!");
            
        } catch (ClassNotFoundException e) {
            System.out.println("Driver Error: MySQL JDBC Driver not found in classpath.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database Error: Failed to connect to the database.");
            e.printStackTrace();
        }
        return conn;
    }

    public static void main(String[] args) {
        getConnection();
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package profilesandspecialisation;

/**
 *
 * @author irfan
 */
import java.util.List;

public class DepartmentAssignment1 {
    
    // --- 1. Private Attributes ---
    private String assignmentID;
    private String staffID;
    private String staffName;
    private String position;
    private String department;
    private String assignmentDate;

    // --- 2. Constructors ---
    public DepartmentAssignment1() {
        // Empty constructor
    }

    public DepartmentAssignment1(String assignmentID, String staffID, String staffName, String position, String department, String assignmentDate) {
        this.assignmentID = assignmentID;
        this.staffID = staffID;
        this.staffName = staffName;
        this.position = position;
        this.department = department;
        this.assignmentDate = assignmentDate;
    }

    // --- 3. Getters and Setters ---
    public String getAssignmentID() { return assignmentID; }
    public void setAssignmentID(String assignmentID) { this.assignmentID = assignmentID; }

    public String getStaffID() { return staffID; }
    public void setStaffID(String staffID) { this.staffID = staffID; }

    public String getStaffName() { return staffName; }
    public void setStaffName(String staffName) { this.staffName = staffName; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getAssignmentDate() { return assignmentDate; }
    public void setAssignmentDate(String assignmentDate) { this.assignmentDate = assignmentDate; }

    // --- 4. Methods ---
    public void assignmentDepartment() {
        // Database logic goes here
    }
    
    public void modifyAssignment() {
        // Database logic goes here
    }
    
    public void deleteAssignment() {
        // Database logic goes here
    }
    
    public List<DepartmentAssignment1> viewAssignment() {
        return null; // Will eventually return a list from the database
    }
    
    public void clearFields() {
        // Logic to clear GUI fields goes here
    }
}

package patientManagement;

public class UserFactory {
    
 public static User verifyAndCreateUser(String username, String password) {

        Patient p = Patient.getPatientFromDatabase(username);
        if (p != null && p.getPassword().equals(password)) {
            return p; 
        }

        return null;
    }
}
